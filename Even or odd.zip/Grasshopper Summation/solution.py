def summation(num):
    pass 
    i = 0
    value =  0
    while i <= num:
        value += i
        i += 1
    return value
# Code here
    
