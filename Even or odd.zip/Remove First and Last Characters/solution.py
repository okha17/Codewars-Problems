def remove_char(s):
    s = s[:-1]
    s = s[1:]
    return s
    #your code here