def no_space(x):
    x = x.replace(' ', '')
    return x
    #your code here