def repeat_str(repeat, string):
    return repeat * string